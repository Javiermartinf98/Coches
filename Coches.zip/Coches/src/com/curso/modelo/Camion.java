package com.curso.modelo;

import java.util.ArrayList;
import java.util.List;

import com.curso.interfaces.Conducible;
/**
 * 
 * @author sinensia
 *
 */

/**
 * Clase hija que hereda de la padre e implementa la interfaz
 */
public class Camion extends Vehiculo implements Conducible
{
	/**
	 * @param tacometro un arraylist que tiene las velocidades del camion
	 */
	private List<Integer> tacometro;
	private boolean isarrancar = false;
	
	/**
	 * Constructor con los atributos del padre e hijo
	 */
	public Camion(String matricula, String marca, String modelo, double potencia, String color)
	{
		super(matricula, marca, modelo, potencia, color);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Getters y Setters de los atributos de camion
	 * @return
	 */
	public List<Integer> getTacometro() {
		return tacometro;
	}
	
	public void setTacometro(List<Integer> tacometro) {
		this.tacometro = tacometro;
	}

	public boolean isIsarrancar() {
		return isarrancar;
	}
	public void setIsarrancar(boolean isarrancar) {
		this.isarrancar = isarrancar;
	}
	
	

	/**
	 * Metodo que te indica por donde circula el coche
	 */
	@Override
	public void conducir() 
	{
		System.out.println("Este vehiculo se utiliza para desplazarte mercancias");		
	}

	/**
	 * Metodo que indica si el coche esta encendido o arrancado
	 */
	@Override
	public void arrancar() 
	{
		if(isarrancar)
		{
			System.out.println("El camion esta parado");
		}
		else
		{
			setIsarrancar(true);
			System.out.println("Camion con Matricula "+getMatricula()+" arrancara enseguida");
		}
	}

	/**
	 * Metodo que muestra el avance que realizo el camion
	 * @param avance recorrido del coche
	 */
	@Override
	public int velocidad(int m, int t) 
	{
		return m/t;
	}

	/**
	 * Metodo que muestra el avance que realizo el coche
	 * @param m metros que recorre
	 * @param t tiempo que emplea
	 * @return
	 */
	@Override
	public void avanzar(int avance) 
	{
		int cont=0;
		int tiempo= 0;
		
		for(int i = 0; i >= avance; i++)
		{
			cont++;
			tiempo = avance + cont;
		}
		System.out.println("El camion con marca "+getMarca()+" a avanzado "+avance+" metros y tiene un tiempo de "+tiempo);
	}

	/**
	 * Metodo que unicamente para el camion
	 */
	@Override
	public void parar() 
	{
		if(!isIsarrancar())
		{
			System.out.println("Primero tengo que arrancar si quiero parar");
		}
		else
		{
			setIsarrancar(false);
			System.out.println("El camion ha parado");
		}
	}

}
