package com.curso.modelo;
/**
 * 
 * @author sinensia
 *
 */
public abstract class Vehiculo 
{
	/**
	 * 
	 * @param matricula que tiene el vehiculo
	 * @param marca del vehiculo
	 * @param modelo del vehiculo
	 * @param potencia que posee el vehiculo
	 */
	private String matricula;
	private String marca;
	private String modelo;
	private double potencia;
	
	/**
	 * Contructor vacio
	 */
	public Vehiculo() {}
	/**
	 * Constructor con todos los parametros
	 */
	public Vehiculo(String matricula, String marca, String modelo, double potencia,String color)
	{
		super();
		this.matricula = matricula;
		this.marca = marca;
		this.modelo = modelo;
		this.potencia = potencia;
	}

	/**
	 * Getters y Setters de los atributos de Vehiculo
	 * @return
	 */
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public double getPotencia() {
		return potencia;
	}
	public void setPotencia(double potencia) 
	{
		this.potencia = potencia;
	}

	/**
	 * ToString formateado con matricula, marca y modelo
	 */
	@Override
	public String toString() 
	{
		return "Vehiculo ( Matricula:" + matricula + ", Marca:" + marca + ", Modelo: " + modelo + ")";
	}
	
	
	
}
