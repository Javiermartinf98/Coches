package com.curso.modelo;

import com.curso.interfaces.Conducible;
/**
 * 
 * @author sinensia
 *
 */

/**
 * Clase Hija que hereda de Vehiculo e implementa interfaz Conducible
 */
public class Coche extends Vehiculo implements Conducible
{
	/**
	 * Constante que indica el numero de ruedas de un coche
	 */
	public static final int numruedas = 4;
	
	private String color;
	private boolean isarrancar = false;
	/**
	 * 
	 * @param color del que sera el coche
	 */
	
	/**
	 * 
	 */
	public Coche() {}
	
	/**
	 * Contructor con los parametros del padre y de la hija
	 */
	public Coche(String matricula, String marca, String modelo, double potencia, String color) {
		super(matricula, marca, modelo, potencia, color);
		this.color = color;
	}
	
	/**
	 * Getters y Setters de los atributos de Coche
	 * @return
	 */
	public String getColor() 
	{
		return color;
	}

	/**
	 * Aqui cambio el valor de color por uno nuevo
	 * @param color
	 */
	public void setColor(String color) 
	{
		color = getColor();
	}

	public boolean isIsarrancar() {
		return isarrancar;
	}
	public void setIsarrancar(boolean isarrancar) {
		this.isarrancar = isarrancar;
	}

	/**
	 * ToString formateado para el coche
	 */
	@Override
	public String toString() 
	{
		return "El coche con matricula "+getMatricula()+" es de color "+this.color+", se corresponde a un "+getMarca()+" "+getModelo();
	}


	/**
	 * Metodo que te indica por donde circula el coche
	 */
	@Override
	public void conducir() 
	{
		System.out.println("Este Coche se utiliza para desplazarte por carretera");		
	}

	/**
	 * Metodo que indica si el coche esta encendido o arrancado
	 */
	@Override
	public void arrancar() 
	{
		if(isarrancar)
		{
			System.out.println("El Coche esta parado");
		}
		else
		{
			setIsarrancar(true);
			System.out.println("Coche con Matricula "+getMatricula()+" arrancara enseguida");
		}
	}

	/**
	 * Metodo que muestra el avance que realizo el coche
	 * @param avance recorrido del coche
	 */
	@Override
	public int velocidad(int m, int t) 
	{
		return m/t;
	}

	/**
	 * Metodo que muestra el avance que realizo el coche
	 * @param m metros que recorre
	 * @param t tiempo que emplea
	 * @return
	 */
	@Override
	public void avanzar(int avance) 
	{
		int cont=0;
		int tiempo= 0;
		
		for(int i = 0; i >= avance; i++)
		{
			cont++;
			tiempo = avance + cont;
		}
		System.out.println("El coche con marca "+getMarca()+" a avanzado "+avance+" metros y tiene un tiempo de "+tiempo);
	}
	
	/**
	 * Metodo que unicamente para el coche
	 */
	@Override
	public void parar() 
	{
		if(!isIsarrancar())
		{
			System.out.println("Primero tengo que arrancar si quiero parar");
		}
		else
		{
			setIsarrancar(false);
			System.out.println("El coche ha parado");
		}
	}

}
