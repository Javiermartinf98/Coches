package com.curso.interfaces;

/**
 * 
 * @author sinensia
 *
 */

/**
 *Interfaz que contiene los metodos
 */
public interface Conducible 
{
	/**
	 * Metodo que te indica por donde circula el coche
	 */
	public void conducir();
	
	/**
	 * Metodo que indica si el coche esta encendido o arrancado
	 */
	public void arrancar();
	
	/**
	 * Metodo que muestra la velocidad del  coche
	 * @param m metros que recorre
	 * @param t tiempo que emplea
	 * @return
	 */
	public int velocidad(int m, int t);
	
	/**
	 * Metodo que muestra el avance que realizo el coche
	 * @param avance recorrido del coche
	 */
	public void avanzar(int avance);
	
	/**
	 * Metodo que unicamente para el vehiculo
	 */
	public void parar();
}
