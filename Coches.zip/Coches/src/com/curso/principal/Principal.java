package com.curso.principal;

import com.curso.modelo.*;
import com.curso.interfaces.*;
/**
 * 
 * @author sinensia
 *
 */

/**
 * Esta clase es la ejecutadora
 */
public class Principal 
{
	public static void main(String[] args)
	{
		Conducible c1 = new Coche("1234-JHK", "Renault", "Megane", 90, "Blanco");
		System.out.println(c1.toString());
		
		Conducible c2 = new Camion("0080-JAA", "Toyota", "Press", 120,"Rojo");
		System.out.println(c2.toString());
		
		Conducible[] vehiculos = {c1,c2};
		
		for(Conducible c : vehiculos)
		{
			if(c instanceof Coche)
			{
				c.conducir();
				System.out.println("**************************************************");
				c.arrancar();
				c.avanzar(20);
				c.avanzar(100);
				c.velocidad(100, 4);
				c.parar();
				c.avanzar(20);
			}
			else
			{
				c.conducir();
				System.out.println("**************************************************");
				c.arrancar();
				c.avanzar(20);
				c.avanzar(100);
				c.velocidad(100, 4);
				c.parar();
				c.avanzar(20);
			}
		}
	}
}
